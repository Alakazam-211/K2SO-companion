# @sew/noise

Microphone noise suppression for the Sew App kit. It runs RNNoise in an AudioWorklet, through
`nnnoiseless`, a pure-Rust port of RNNoise (BSD-3-Clause), built to WebAssembly from
`crates/sew-noise-wasm`. There is no C code and no network call, and the model is compiled into
the `.wasm`.

The kit uses it for this reason: on a Mac, the OS's voice isolation made voices too quiet, and
turning it off let background noise through. With this node, the kit can turn the browser's own
suppression off and run its own.

## API

```ts
import { createNoiseProcessor } from '@sew/noise'; // vendor/sew-noise/<dir> in sew-web

const ctx = new AudioContext({ sampleRate: 48000 }); // see "Sample rate"
const node = await createNoiseProcessor(ctx);        // Promise<NoiseNode>
ctx.createMediaStreamSource(micStream).connect(node);
node.connect(ctx.createMediaStreamDestination());    // publish this track
// …
node.setEnabled(false); // bypass, at the same latency (no click); true turns it back on
node.dispose();         // stop the processor, free its WASM memory, disconnect. Idempotent.
```

- `createNoiseProcessor(ctx: AudioContext, options?): Promise<AudioWorkletNode & { dispose(), setEnabled(on), latencySamples, disposed }>`
  - The node has one input and one output, both mono. A stereo input is down-mixed: `channelCount: 1`, `'explicit'`, `'speakers'`.
  - The promise resolves once the WASM is running in the worklet. Until then the node outputs silence, never the raw microphone.
  - The promise rejects in three cases:
    - the context has no `audioWorklet` (the page is not a secure context);
    - the rate is outside 8–192 kHz, or is not a whole number;
    - the `.wasm` fails to load, or the worklet reports an error. This also has a 10 s timeout (`readyTimeoutMs`).
  - `options.wasmUrl` and `options.workletUrl` override where the files are. By default they sit next to `sew-noise.js` (`new URL('./…', import.meta.url)`, which Vite and webpack 5 resolve as assets).
  - The worklet module is added once per AudioContext. The `.wasm` is fetched once per page and compiled once per AudioContext.
- `latencySamples` is the delay the node adds, at the context rate. At 48 kHz it is **960 samples (20 ms)**: 10 ms of buffering, because render quanta of 128 samples do not line up with RNNoise's 480-sample frames, plus RNNoise's own 10 ms frame.
- `NoiseNode` is the type the kit names (an alias of `NoiseProcessorNode`). There is no `STUB` export: the kit reads a missing `STUB` as the real build.
- Constants: `NOISE_SAMPLE_RATE` (48000), `NOISE_FRAME` (480), `NOISE_PROCESSOR_NAME` (`'sew-noise'`).

## Sample rate

RNNoise works only at 48 kHz. Create the AudioContext with `{ sampleRate: 48000 }`: the browser
then resamples the microphone once, well, and the worklet does no conversion.

If the context runs at another rate (for example 44.1 kHz on some Macs, or when you cannot set
it), the worklet converts to 48 kHz and back with linear interpolation, at about the same 20 ms
(`latencySamples` gives the exact figure, 886 at 44.1 kHz). This is fine at 44.1 kHz and above.
Below 44.1 kHz the conversion down aliases audibly, so use 48 kHz.

## Bundlers: emit both files, never inline them

The loader finds `noise.worklet.js` and `sew_noise_wasm_bg.wasm` with literal
`new URL('./noise.worklet.js', import.meta.url)` and
`new URL('./sew_noise_wasm_bg.wasm', import.meta.url)`, then `audioWorklet.addModule()`s the
first and `fetch()`es the second. It never makes a `blob:` or `data:` URL and never calls
`URL.createObjectURL` (`test/unit.mjs` fails if either file ever does), so a page whose CSP
allows only `'self'` for scripts and fetches can load it.

A bundler must therefore emit both files as separate same-origin assets and must not inline
them. Vite (and webpack 5's asset modules) emit `new URL('./…', import.meta.url)` targets as
assets, but Vite inlines an asset under `build.assetsInlineLimit` (4 KiB by default) as a
`data:` URL, which such a CSP blocks. Both files are well over that (the worklet is about 7 KB,
the `.wasm` about 360 KB), so the defaults are fine; do not raise the limit above them, and do
not use a plugin that inlines workers or worklets.

If an App serves the files somewhere else (another path, a CDN), it passes their URLs:
`createNoiseProcessor(ctx, { wasmUrl, workletUrl })`. The CSP must then allow that origin (see
below).

## CSP

The page that loads the node needs these Content-Security-Policy directives:

| Directive | Why |
|---|---|
| `script-src 'self' 'wasm-unsafe-eval'` | `audioWorklet.addModule()` loads `noise.worklet.js` as a script, and the worklet compiles the WASM (`WebAssembly.instantiate`). Without `'wasm-unsafe-eval'` (or the broader `'unsafe-eval'`), the browser refuses the compile and the promise rejects. |
| `connect-src 'self'` | The loader `fetch()`es `sew_noise_wasm_bg.wasm`. |
| `worker-src` | Not needed: worklets are governed by `script-src`, not `worker-src`. |

If the files are served from another origin (a CDN), add that origin to `script-src` and
`connect-src`. The `.wasm` should be served as `application/wasm`. The loader passes bytes, not a
streaming compile, so a wrong MIME type does not break it, but it is still the right type.

## Files (the vendored build)

| File | What |
|---|---|
| `sew-noise.js` | The ESM loader (`createNoiseProcessor`). |
| `noise.worklet.js` | The AudioWorkletProcessor `sew-noise`, bundled with the wasm-bindgen glue into one module with no imports. |
| `sew_noise_wasm_bg.wasm` | The suppressor. |
| `index.d.ts` | The TypeScript declarations (`createNoiseProcessor`, `NoiseNode`). |
| `package.json` | `@sew/noise`, its `files` and `exports`: the layout of sew-web's `vendor/sew-noise/<dir>`. |
| `NOTICE` | @sew/noise's notice and nnnoiseless's BSD-3-Clause text. |
| `LICENSE-MIT`, `LICENSE-APACHE` | MIT OR Apache-2.0, at your option (@sew/noise itself). |
| `notices/THIRD_PARTY_NOTICES.txt` | Every crate in the WASM, with its licence texts. nnnoiseless's BSD-3-Clause notice is required with any redistribution. |
| `VERSION`, `SHA256SUMS`, `README.md` | Build identity and hashes. |

## Vendoring into sew-web

The bundle directory is the package as sew-web vendors it (`vendor/sew-noise/<dir>`, which
replaces the pass-through stub): `package.json` names `@sew/noise` and lists its `files` and
`exports` (`.`, `./noise.worklet.js`, `./sew_noise_wasm_bg.wasm`), and `SHA256SUMS` pins every
file.
The kit's build stamps the version in `package.json`, applies the kit's licence (MIT OR
Apache-2.0: `LICENSE-MIT`, `LICENSE-APACHE`, the kit's `NOTICE` header, `CHANGELOG.md`) and redoes
those rows of `SHA256SUMS`.

## Building

The build runs only on a Linux runner, never on a Mac:

```
scripts/build-noise-wasm.sh [--repro]
```

The script uses the pinned `wasm-bindgen-cli` and `binaryen` from `scripts/linux/tools.lock`, and
Node, `esbuild` and `typescript` from `package-lock.json`. It prints the bundle directory, the
sizes and the SHA-256 of every file. With `--repro`, it builds a second time in a fresh target
directory and fails if any hash differs.

The lane tests are `scripts/test-linux.sh -- -p sew-noise-wasm --features lanes --test wasm_lane`.
They check four things:

- there are no C crates and no non-permissive licences;
- the size budget (`size-budget.json`) and the reproducible build;
- `tests/node.rs` on wasm32 under Node;
- `test/unit.mjs` on the built bundle, which drives the real worklet in a stand-in
  AudioWorkletGlobalScope with real speech plus noise, and drives the loader against a stand-in
  AudioContext.

The Rust half is tested natively by `cargo test -p sew-noise`, which also runs the quality and CPU
checks.
