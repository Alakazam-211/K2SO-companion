# Changelog: @sew/noise

## 0.8.1 (2026-11-06)

- Rebuilt at Sew 0.8.1 (the version in `VERSION`, `package.json` and the banners). No API or behaviour change.

## 0.8.0 (2026-11-05)

- Rebuilt at Sew 0.8.0 (the version in `VERSION`, `package.json` and the banners). No API or
  behaviour change.

## 0.7.4 (2026-11-05)

- Rebuilt at Sew 0.7.4 (the version in `VERSION`, `package.json` and the banners). No API or
  behaviour change.

## 0.7.3 (2026-11-04)

- Licence: Alakazam Labs' code in this package (`sew-noise.js`, `noise.worklet.js`,
  `index.d.ts`, and the Sew crates in `sew_noise_wasm_bg.wasm`) is now `MIT OR Apache-2.0`, at
  your option; it was `Apache-2.0`. The package ships `LICENSE-MIT` and `LICENSE-APACHE` instead
  of `LICENSE`, and `package.json`'s `license` says `MIT OR Apache-2.0`.
- `NOTICE` states the new licence over the build's nnnoiseless 0.5.2 notice (BSD-3-Clause,
  unchanged); `notices/THIRD_PARTY_NOTICES.txt` is unchanged except its licence line. The code
  and the WebAssembly are unchanged.
