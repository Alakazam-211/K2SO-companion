/** RNNoise's rate: run the AudioContext at this rate when you can. */
export declare const NOISE_SAMPLE_RATE = 48000;
/** RNNoise's frame (10 ms at 48 kHz). */
export declare const NOISE_FRAME = 480;
/** The AudioWorkletProcessor's registered name. */
export declare const NOISE_PROCESSOR_NAME = "sew-noise";
/** The context rates the worklet takes. */
export declare const NOISE_MIN_RATE = 8000;
export declare const NOISE_MAX_RATE = 192000;
/** The node `createNoiseProcessor` resolves to: an AudioWorkletNode plus these. */
export interface NoiseProcessorNode extends AudioWorkletNode {
    /** Stops the processor, frees its WASM memory and disconnects the node. Idempotent. */
    dispose(): void;
    /** Suppression on (the default) or bypassed; bypass keeps the latency, so no click. */
    setEnabled(on: boolean): void;
    /** The delay the node adds, in samples at the context rate (960 at 48 kHz). */
    readonly latencySamples: number;
    /** Whether `dispose()` ran. */
    readonly disposed: boolean;
}
/** The kit's name for the node (sew-web `vendor/sew-noise`'s interface). */
export type NoiseNode = NoiseProcessorNode;
export interface NoiseProcessorOptions {
    /** Where the .wasm is (default: next to this module, `sew_noise_wasm_bg.wasm`). */
    wasmUrl?: string | URL;
    /** Where the worklet script is (default: next to this module, `noise.worklet.js`). */
    workletUrl?: string | URL;
    /** How long to wait for the worklet to load the WASM (default 10 s). */
    readyTimeoutMs?: number;
}
/**
 * Creates a noise-suppression node on `ctx` (48 kHz mono in and out; other rates are resampled
 * inside the worklet). Resolves once the WASM runs in the worklet; rejects if the context has no
 * AudioWorklet (an insecure page), the rate is outside 8–192 kHz, or the WASM fails to load.
 */
export declare function createNoiseProcessor(ctx: BaseAudioContext, options?: NoiseProcessorOptions): Promise<NoiseProcessorNode>;
