# Changelog: @sew/e2ee

## 0.8.2 (2026-11-06)

- Rebuilt at Sew 0.8.2 (the version in `VERSION`, `package.json`, the banner and the
  WebAssembly). No API or behaviour change.

## 0.8.1 (2026-11-06)

- Rebuilt at Sew 0.8.1 (the version in `VERSION`, `package.json`, the banner and the
  WebAssembly; `BUILD.json` names only the build box's arch and OS). No API or behaviour change.

## 0.8.0 (2026-11-05)

- Rebuilt at Sew 0.8.0 (the version in `VERSION`, `package.json`, the banner and the
  WebAssembly). No API or behaviour change.

## 0.7.4 (2026-11-05)

- Rebuilt at Sew 0.7.4 (the version in `VERSION`, `package.json`, the banner and the
  WebAssembly). No API or behaviour change.

## 0.7.3 (2026-11-04)

- Licence: Alakazam Labs' code in this package (`sew-e2ee.js`, `types/`, and the Sew crates in
  `sew_e2ee_wasm_bg.wasm`) is now `MIT OR Apache-2.0`, at your option; it was `Apache-2.0`. The
  package ships `LICENSE-MIT` and `LICENSE-APACHE` instead of `LICENSE`, and `package.json`'s
  `license` says `MIT OR Apache-2.0`.
- `e2ee.worker.js` is livekit-client's own E2EE worker and stays `Apache-2.0` only, in its own
  file. `e2ee.worker.js.LICENSE.txt` says so and names its upstream version and the packages it
  bundles.
- New: `NOTICE` (the package's attribution) and `notices/THIRD_PARTY_NOTICES.txt` (the worker's
  packages and every Rust crate in the WebAssembly, each with its full licence texts). The code
  and the WebAssembly are unchanged.
