# @sew/e2ee 0.8.2

Sew's end-to-end encryption for voice and video calls: the MLS group state in WebAssembly
(`sew_e2ee_wasm_bg.wasm`, the Rust crate sew-e2ee-wasm), the key provider and session driver
for livekit-client 2.22.3 (`sew-e2ee.js`), and livekit-client's E2EE worker
(`e2ee.worker.js`). Part of the Sew App kit; `@sew/voice` loads it lazily on the first call.

- Licence: MIT OR Apache-2.0, at your option (LICENSE-MIT, LICENSE-APACHE), except
  `e2ee.worker.js`: livekit-client's own worker, Apache-2.0 only (`e2ee.worker.js.LICENSE.txt`).
  The WebAssembly links third-party Rust crates under their own licences (MIT, Apache-2.0, BSD and
  others). NOTICE and `notices/THIRD_PARTY_NOTICES.txt` name them with their texts; an App that
  serves this package must serve their notices, which `@sew/bff`'s `sew-notices` writes.
- Built from Alakazam-211/sew 2275837ba0e4ec252a95dd4dfe637545b4f97b1b on Linux; BUILD.json says how, SHA256SUMS pins every file.
- Peer: livekit-client 2.22.3 exactly (the only SDK Sew's calls accept).
- Serve `e2ee.worker.js` and `sew_e2ee_wasm_bg.wasm` from your own origin (CSP
  `worker-src 'self'`, `script-src 'self' 'wasm-unsafe-eval'`) and pass their URLs to @sew/voice.
