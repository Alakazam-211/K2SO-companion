/* tslint:disable */
/* eslint-disable */

/**
 * The capabilities a bridge declares (built only by `JsBridge`, D11).
 */
export class WasmCaps {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * For `@sew/e2ee`'s `JsBridge` only: `sender_key_index` from the capability probe, the
     * `livekit-client` version, the browser.
     */
    static fromJsBridge(sender_key_index: boolean, sdk_version: string, browser: string): WasmCaps;
    /**
     * The wire object (JSON).
     */
    toJson(): string;
}

/**
 * One device's client (identity + trust): prepares key packages.
 */
export class WasmClient {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Whether the certificate has less than 7 days left (silent K12 renewal).
     */
    needsRenewal(now: number): boolean;
    /**
     * A client for the stored device (JSON from the IndexedDB store). Throws when the
     * certificate is refused (the app enrolls again).
     */
    static new(stored_json: string, trust: WasmTrust, me: string, now: number): WasmClient;
    /**
     * Offline: a fresh leaf key for `call:<channel_id>` and the bytes the device key signs.
     */
    prepareKeyPackage(channel_id: string, now: number): WasmPendingKp;
    /**
     * Adds revoked serials (a `revoked` dispatch before any session).
     */
    revoke(serials: string[]): void;
    /**
     * The device id (decimal).
     */
    readonly deviceId: string;
}

/**
 * An enrollment in progress (K11).
 */
export class WasmEnrollment {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Verifies the K11/K12 answer (JSON); returns the device to store (JSON).
     */
    static accept(resp_json: string, trust: WasmTrust, me: string, pubkey: Uint8Array, now: number): string;
    /**
     * Starts an enrollment for the device public key (65-byte SEC1).
     */
    static begin(pubkey: Uint8Array, platform: string, label: string, install_id: string, me: string): WasmEnrollment;
    /**
     * The K11 body (JSON) with the proof (raw r‖s).
     */
    request(proof: Uint8Array): string;
    /**
     * The proof message the device key signs.
     */
    readonly message: Uint8Array;
}

/**
 * One output of the session for the TS driver.
 */
export class WasmOutput {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The key bytes of an install, activate or retire. Taken once: the WASM copy is zeroized
     * as it is handed over; the TS wrapper imports and zero-fills its copy.
     */
    takeIkm(): Uint8Array | undefined;
    /**
     * The details as JSON (no key bytes).
     */
    readonly json: string;
    /**
     * `send`, `key`, `sign`, `check_slot`, `status`, `roster`.
     */
    readonly kind: string;
}

/**
 * A key package waiting for its device signature.
 */
export class WasmPendingKp {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Verifies the signature and builds the package.
     */
    finish(sig: Uint8Array): WasmPreparedKp;
    /**
     * The bytes to sign (raw r‖s answer).
     */
    readonly message: Uint8Array;
}

/**
 * A signed key package (single use).
 */
export class WasmPreparedKp {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Starts the session from the join's `CallKeysInit` (JSON). Consumes the package.
     */
    intoSession(client: WasmClient, init_json: string, gateway_session: string, now: number): WasmSession;
    /**
     * Over 60 min old or past the server TTL.
     */
    isStale(now: number): boolean;
    /**
     * The K1 `e2ee` object (JSON).
     */
    joinField(caps: WasmCaps, gateway_session: string): string;
    /**
     * The K2 body for a move (JSON).
     */
    keyJoinRequest(join_id: string, caps: WasmCaps, gateway_session: string): string;
    /**
     * Takes K16's answer item (JSON); refuses a ref that is not the package's `hash_ref`.
     */
    setRef(item_json: string): void;
    /**
     * The K16 body (JSON).
     */
    uploadBody(): string;
}

/**
 * The per-call state machine.
 */
export class WasmSession {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The bridge applied everything up to `fence`.
     */
    handleInstalled(now: number, fence: number): void;
    /**
     * The answer to a `send` output: the HTTP status and the JSON body.
     */
    handleReply(now: number, request: number, status: number, body_json: string): void;
    /**
     * The device signature for a `sign` output.
     */
    handleSignature(now: number, request: number, sig: Uint8Array): void;
    /**
     * Runs due timers.
     */
    handleTimeout(now: number): void;
    /**
     * A transport failure for a `send` (after the wrapper's own retries).
     */
    handleTransportFailure(now: number, request: number): void;
    /**
     * Applies one input (JSON, tagged: `{"server": …}`, `"resumed"`, `{"reidentified": "…"}`,
     * `{"ready": …}`, `{"recording": …}`, `{"missing_key": …}`, `{"undecryptable": …}`,
     * `{"decrypt_ok": "p_…"}`, `{"sender_slot": n}`, `{"engine_attack": …}`,
     * `{"media_participants": […]}`, `{"voice_members": […]}`).
     */
    handle(now: number, input_json: string): void;
    /**
     * Whether an engine identity is in the key group.
     */
    isKeyed(identity: string): boolean;
    /**
     * Teardown (`Key(Clear)` follows).
     */
    leave(now: number): void;
    /**
     * The local send slot.
     */
    localSlot(): number | undefined;
    /**
     * The next output, if any.
     */
    pollOutput(): WasmOutput | undefined;
    /**
     * The next timer (unix ms), if any.
     */
    pollTimeout(): number | undefined;
    /**
     * The roster (JSON).
     */
    roster(): string;
    /**
     * The security code, `null` when hidden or not active.
     */
    securityCode(): string | undefined;
    /**
     * The last status (JSON).
     */
    status(): string | undefined;
    /**
     * The call id.
     */
    readonly callId: string;
    /**
     * The local engine identity.
     */
    readonly lkIdentity: string;
}

/**
 * The install's trust anchors (READY `call_keys`, TOFU pins).
 */
export class WasmTrust {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Reads READY's `call_keys` (JSON) against the stored pins (JSON or `undefined`). A
     * changed pin throws `server identity changed`; first-sight pins come back in `newPins`
     * for the store.
     */
    static fromReady(ready_json: string, install_id: string, pins_json?: string | null): WasmTrust;
    /**
     * Adds revoked serials (decimal strings).
     */
    revoke(serials: string[]): void;
    /**
     * Whether READY said the CRL is partial (page it with K15).
     */
    readonly crlPartial: boolean;
    /**
     * Pins to store (first sight), as JSON.
     */
    readonly newPins: string | undefined;
}

/**
 * The library version (`lib` in caps is `sew-e2ee/<this>`).
 */
export function libVersion(): string;

/**
 * What a join failure means: `"retry"` (prepare, upload and retry once), or throws
 * `unsupported:<what>` / `key_package` / `join refused`.
 */
export function onJoinFailure(status: number, body_json: string, already_retried: boolean): string;

/**
 * Opens one chunk of a recorder-sealed segment (S4 stream format). Throws on any mismatch; no
 * plaintext is returned then. The TS wrapper zero-fills `key` after the call.
 */
export function openRecordingChunk(key: Uint8Array, header: Uint8Array, index: number, last: boolean, ct: Uint8Array): Uint8Array;

/**
 * The chunk layout of a sealed file (JSON `{chunks, chunk_size, plaintext_len}`).
 */
export function recordingChunkLayout(file_len: number, header: Uint8Array): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_wasmcaps_free: (a: number, b: number) => void;
    readonly __wbg_wasmclient_free: (a: number, b: number) => void;
    readonly __wbg_wasmenrollment_free: (a: number, b: number) => void;
    readonly __wbg_wasmoutput_free: (a: number, b: number) => void;
    readonly __wbg_wasmpendingkp_free: (a: number, b: number) => void;
    readonly __wbg_wasmpreparedkp_free: (a: number, b: number) => void;
    readonly __wbg_wasmsession_free: (a: number, b: number) => void;
    readonly __wbg_wasmtrust_free: (a: number, b: number) => void;
    readonly libVersion: (a: number) => void;
    readonly onJoinFailure: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly openRecordingChunk: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly recordingChunkLayout: (a: number, b: number, c: number, d: number) => void;
    readonly wasmcaps_fromJsBridge: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly wasmcaps_toJson: (a: number, b: number) => void;
    readonly wasmclient_deviceId: (a: number, b: number) => void;
    readonly wasmclient_needsRenewal: (a: number, b: number) => number;
    readonly wasmclient_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly wasmclient_prepareKeyPackage: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly wasmclient_revoke: (a: number, b: number, c: number) => void;
    readonly wasmenrollment_accept: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly wasmenrollment_begin: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => void;
    readonly wasmenrollment_message: (a: number, b: number) => void;
    readonly wasmenrollment_request: (a: number, b: number, c: number, d: number) => void;
    readonly wasmoutput_json: (a: number, b: number) => void;
    readonly wasmoutput_kind: (a: number, b: number) => void;
    readonly wasmoutput_takeIkm: (a: number) => number;
    readonly wasmpendingkp_finish: (a: number, b: number, c: number, d: number) => void;
    readonly wasmpendingkp_message: (a: number, b: number) => void;
    readonly wasmpreparedkp_intoSession: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly wasmpreparedkp_isStale: (a: number, b: number) => number;
    readonly wasmpreparedkp_joinField: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly wasmpreparedkp_keyJoinRequest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly wasmpreparedkp_setRef: (a: number, b: number, c: number, d: number) => void;
    readonly wasmpreparedkp_uploadBody: (a: number, b: number) => void;
    readonly wasmsession_callId: (a: number, b: number) => void;
    readonly wasmsession_handle: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly wasmsession_handleInstalled: (a: number, b: number, c: number, d: number) => void;
    readonly wasmsession_handleReply: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly wasmsession_handleSignature: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly wasmsession_handleTimeout: (a: number, b: number) => void;
    readonly wasmsession_handleTransportFailure: (a: number, b: number, c: number, d: number) => void;
    readonly wasmsession_isKeyed: (a: number, b: number, c: number) => number;
    readonly wasmsession_leave: (a: number, b: number) => void;
    readonly wasmsession_lkIdentity: (a: number, b: number) => void;
    readonly wasmsession_localSlot: (a: number) => number;
    readonly wasmsession_pollOutput: (a: number) => number;
    readonly wasmsession_pollTimeout: (a: number, b: number) => void;
    readonly wasmsession_roster: (a: number, b: number) => void;
    readonly wasmsession_securityCode: (a: number, b: number) => void;
    readonly wasmsession_status: (a: number, b: number) => void;
    readonly wasmtrust_crlPartial: (a: number) => number;
    readonly wasmtrust_fromReady: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly wasmtrust_newPins: (a: number, b: number) => void;
    readonly wasmtrust_revoke: (a: number, b: number, c: number) => void;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export3: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
