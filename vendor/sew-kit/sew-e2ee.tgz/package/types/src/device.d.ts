export interface DeviceRecord {
    installId: string;
    /** The device key pair (private key non-extractable). */
    keyPair?: CryptoKeyPair;
    /** `JsStoredDevice` JSON (public data). */
    device?: string;
    /** `JsPins` JSON. */
    pins?: string;
}
/**
 * The IndexedDB device store of one install. One record per install by default; `profile`
 * (S47.3, additive) keeps several devices of the same install apart in one origin (a test page
 * holding two members, or an app with more than one signed-in account): the record key becomes
 * `<installId>/<profile>`.
 */
export declare class IdbDeviceStore {
    private readonly db;
    readonly installId: string;
    private readonly key;
    private constructor();
    static open(installId: string, profile?: string): Promise<IdbDeviceStore>;
    load(): Promise<DeviceRecord>;
    save(rec: DeviceRecord): Promise<void>;
    /** Forgets the device and the pins (a new enrollment accepts new pins). */
    clear(): Promise<void>;
}
/** A fresh device key: ECDSA P-256, private key non-extractable, no user presence (D14). */
export declare function generateDeviceKey(): Promise<CryptoKeyPair>;
/** The 65-byte uncompressed SEC1 public key. */
export declare function publicKeySec1(kp: CryptoKeyPair): Promise<Uint8Array>;
/** ECDSA-P256-SHA256 over `message`: raw r‖s (WebCrypto's IEEE P1363 output). */
export declare function signWithDevice(kp: CryptoKeyPair, message: Uint8Array): Promise<Uint8Array>;
