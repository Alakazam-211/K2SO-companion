import { BaseKeyProvider } from 'livekit-client';
import type { KeyInfo } from 'livekit-client';
/** The SDK configuration every bridge uses (§13.1; `bridge_config_constants`). */
export declare const SEW_KEY_OPTIONS: {
    readonly sharedKey: false;
    readonly ratchetSalt: "LKFrameEncryptionKey";
    readonly ratchetWindowSize: 0;
    readonly failureTolerance: -1;
    readonly keyringSize: 64;
    readonly keySize: 128;
};
export declare class SewKeyProvider extends BaseKeyProvider {
    private remote;
    private local;
    private reconnectWindow;
    private stuck;
    private wrongSlot;
    private keyTap;
    constructor();
    /** Imports 32 IKM bytes as HKDF material (utils.ts:61-68), then zero-fills `ikm`. */
    private material;
    private set;
    /** A remote sender's key at `slot` (Install). */
    install(identity: string, slot: number, ikm: Uint8Array): Promise<void>;
    /** The local key AND the sender switch (Activate; J2). */
    activate(identity: string, slot: number, ikm: Uint8Array): Promise<void>;
    /** Overwrites a remote slot with random bytes (Retire). A local retire is ignored (J4). */
    retire(identity: string, slot: number, filler: Uint8Array): Promise<void>;
    /** The identity left the key group. */
    forget(identity: string): void;
    /** Every remote live slot (Clear). */
    liveRemoteSlots(): Array<[string, number]>;
    /** The local send slot. */
    localSlot(): number | undefined;
    /** Opens/closes the Reconnecting → SignalConnected window (previous keys reposted inside). */
    setReconnectWindow(open: boolean): void;
    /** Test-only (`SEW_E2EE_TESTING` builds): the sender never switches. */
    setStuckSenderForTest(on: boolean): void;
    /** Test-only (`SEW_E2EE_TESTING` builds): later Activates install the local key at `slot`. */
    setWrongSlotForTest(slot: number | undefined): void;
    /**
     * Test-only (`SEW_E2EE_TESTING` builds; S47 #121): `tap` gets a copy of every IKM this
     * provider imports (installs, activates and retire fillers), for the lane's key-material scan.
     * Never in release bundles (S51 test 144).
     */
    setKeyTapForTest(tap: ((ikm: Uint8Array, meta: KeyTapMeta) => void) | undefined): void;
    /** The live identity count and key count (the `js_getkeys_excludes_retired_and_departed` bound). */
    stats(): {
        identities: number;
        keys: number;
    };
    getKeys(): KeyInfo[];
    getLatestManuallySetKeyIndex(): number;
}
/** What a test-only key tap is told about each imported IKM (never the bytes' meaning). */
export interface KeyTapMeta {
    op: 'install' | 'activate' | 'retire';
    identity: string;
    slot: number;
}
