import { type WasmPreparedKp } from '../pkg/sew_e2ee_wasm.js';
import { JsBridge } from './bridge';
import { IdbDeviceStore } from './device';
export { E2eeUnsupported, JsBridge, detectBrowser, type KeyOp, type ProbeResult } from './bridge';
export { IdbDeviceStore, type DeviceRecord } from './device';
export { SEW_KEY_OPTIONS, SewKeyProvider, type KeyTapMeta } from './provider';
export { createE2eeWorker, filterCounts, filterWorkerMessage, isSewWorker, onEngineAttack, setWorkerFilterForTest, } from './worker';
/** One key route request, as the app's transport sends it. */
export interface KeyRequestJs {
    kind: string;
    path: string;
    body: unknown;
}
/** The app's HTTP calls to S50's key routes (K3–K10, K16). */
export interface KeyTransport {
    send(req: KeyRequestJs): Promise<{
        status: number;
        body: unknown;
    }>;
}
/** The app's device routes (K11/K12). */
export interface EnrollTransport {
    enroll(body: unknown): Promise<{
        status: number;
        body: unknown;
    }>;
}
export type Status = {
    state: string;
    [k: string]: unknown;
};
/** The call-key session the app feeds (§14.6). */
export interface SewCallSession {
    onServer(msg: unknown): void;
    onReidentified(gatewaySession: string): void;
    onRecording(r: {
        recordingId: string | null;
        consent: 'granted' | 'denied' | 'pending';
    }): void;
    onMediaParticipants(ids: string[]): void;
    onVoiceMembers(members: string[]): void;
    leave(): void;
    roster(): unknown[];
    securityCode(): string | null;
    status(): Status | null;
    on(ev: 'status' | 'roster', cb: () => void): void;
}
/** A signed key package, uploaded (K16) and ready to join. */
export interface PreparedKp {
    readonly inner: WasmPreparedKp;
}
export interface SewE2eeClient {
    prepareKeyPackage(channelId: string, transport: KeyTransport): Promise<PreparedKp>;
    joinField(p: PreparedKp, gatewaySession: string, bridge: JsBridge): unknown;
    keyJoinRequest(p: PreparedKp, joinId: string, gatewaySession: string, bridge: JsBridge): unknown;
    /** What a refused join means: `'retry'` (prepare, upload, retry once) or it throws. */
    joinFailure(status: number, body: unknown, alreadyRetried: boolean): 'retry';
    session(p: PreparedKp, init: unknown, gatewaySession: string, bridge: JsBridge, transport: KeyTransport): SewCallSession;
}
export interface SewE2ee {
    /** `profile` (additive, S47.3) separates several devices of one install in one origin. */
    deviceStore(installId: string, profile?: string): Promise<IdbDeviceStore>;
    enroll(opts: {
        store: IdbDeviceStore;
        transport: EnrollTransport;
        me: string;
        label: string;
        ready: unknown;
    }): Promise<void>;
    client(opts: {
        installId: string;
        me: string;
        ready: unknown;
        store: IdbDeviceStore;
    }): Promise<SewE2eeClient>;
}
/** Loads the WASM module (`wasm`: its URL or a fetch Response). */
export declare function loadSewE2ee(wasm?: URL | Response): Promise<SewE2ee>;
/** Opens one chunk of a recorder-sealed segment (§15.3, P1 prep); zero-fills `key`. */
export declare function openRecordingChunk(key: Uint8Array, header: Uint8Array, index: number, last: boolean, ct: Uint8Array): Uint8Array;
/** The chunk layout of a sealed file of `fileLen` bytes. */
export declare function recordingChunkLayout(fileLen: number, header: Uint8Array): {
    chunks: number;
    chunk_size: number;
    plaintext_len: number;
};
