export type EngineAttackKind = 'unencrypted_track' | 'sif_trailer';
export interface FilterResult {
    /** The message to post, or `undefined` to drop it. */
    message?: unknown;
    /** What the engine tried, if anything. */
    attack?: {
        kind: EngineAttackKind;
        identity?: string;
    };
}
/** The pure J-D1 filter over one worker message. */
export declare function filterWorkerMessage(message: unknown): FilterResult;
/**
 * Test-only (`SEW_E2EE_TESTING` builds; S47.3): turns the J-D1 filter of `w` off or on again.
 * S47's `sif_injection_not_rendered_js` and `fake_unencrypted_publication_no_decrypt_disable_js`
 * need a control run without the filter to prove they can see the attack. A release bundle has
 * no way to turn the filter off (S51 test 144).
 */
export declare function setWorkerFilterForTest(w: Worker, on: boolean): void;
/** Whether `w` was made by {@link createE2eeWorker} (J-D2). */
export declare function isSewWorker(w: Worker): boolean;
/** Subscribes to the filter's reports for this worker. */
export declare function onEngineAttack(w: Worker, cb: (kind: EngineAttackKind, identity?: string) => void): () => void;
/** How many messages the filter dropped and rewrote. */
export declare function filterCounts(w: Worker): {
    dropped: number;
    rewritten: number;
};
/**
 * The livekit-client E2EE worker (`workerUrl` serves `livekit-client/e2ee-worker`) with the
 * J-D1 filter installed. Pass the result to the Room and to `new JsBridge(room, provider, w)`.
 */
export declare function createE2eeWorker(workerUrl: URL | string, options?: WorkerOptions): Worker;
