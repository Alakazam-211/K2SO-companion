import type { LocalTrack, Room, TrackPublishOptions } from 'livekit-client';
import { SewKeyProvider } from './provider';
import { type EngineAttackKind } from './worker';
/** One key event of the core (`WasmOutput` kind `key`). */
export interface KeyOp {
    op: 'install' | 'activate' | 'retire' | 'forget' | 'fence' | 'clear';
    identity?: string;
    slot?: number;
    fence?: number;
}
export interface ProbeResult {
    ok: boolean;
    reason?: 'encoded_transform' | 'worker' | 'key_provider_api' | 'hkdf' | 'key_ring_size';
}
/**
 * This browser cannot run an encrypted call (§16, S51 test 85): `joinField` throws it before
 * any join request is built, with the probe's reason (S47.3, additive).
 */
export declare class E2eeUnsupported extends Error {
    readonly reason: string;
    constructor(reason: string);
}
/** The events a bridge reports to its session. */
export interface BridgeSink {
    installed(fence: number): void;
    missingKey(identity: string, since: number): void;
    engineAttack(kind: EngineAttackKind | 'encryption_downgrade', identity?: string): void;
}
/** `chrome`, `firefox`, `safari` or `other`, as the server's refused_browsers expects. */
export declare function detectBrowser(): 'chrome' | 'firefox' | 'safari' | 'other';
export declare class JsBridge {
    private readonly room;
    private readonly provider;
    private readonly worker;
    private chain;
    private lastIdentity;
    private fences;
    private nextFence;
    private armed;
    private sink;
    private probeOk;
    private stuck;
    /** Unencrypted publications unsubscribed by the J-INV3 backstop. */
    backstopRefused: number;
    /** The last §16 probe (`probeNow` or `arm`). */
    lastProbe: ProbeResult | undefined;
    constructor(room: Room, provider: SewKeyProvider, worker: Worker);
    /** The §16 probe (async: the HKDF import is). */
    static probe(): Promise<ProbeResult>;
    /**
     * Runs the §16 probe now, so `caps()` (the join's `sender_key_index`) is right before the
     * room connects (S47.3, additive). `arm()` cannot run before the connect: `room.isE2EEEnabled`
     * turns true only when the worker answers the `enable` the SDK posts on `SignalConnected`, and
     * the connect needs the token the join returns.
     */
    probeNow(): Promise<ProbeResult>;
    /** Runs the probe and arms the room (J-D2). Throws when E2EE stays off. */
    arm(): Promise<void>;
    /** Publishes only on an armed room (the local encoder passes frames through otherwise). */
    publishTrack(track: LocalTrack, options?: TrackPublishOptions): Promise<import("livekit-client").LocalTrackPublication>;
    /** What the session reports to the server (D11: only a bridge builds caps). */
    capsInputs(): {
        senderKeyIndex: boolean;
        sdkVersion: string;
        browser: string;
    };
    attach(sink: BridgeSink): void;
    /** Test-only stuck-sender mode (§13.6; `SEW_E2EE_TESTING` builds only). */
    setStuckSenderForTest(on: boolean): void;
    /**
     * Test-only (`SEW_E2EE_TESTING` builds; S47.3 / S51 test 136): every later Activate installs
     * the local key at `slot` instead of the epoch's, so the self-check sees a wrong sender index
     * (and its re-apply stays wrong). `undefined` turns it off. Unlike the stuck mode the
     * self-check runs.
     */
    setWrongSenderSlotForTest(slot: number | undefined): void;
    private post;
    /** Applies one key event, in order with every earlier one. */
    apply(op: KeyOp, ikm?: Uint8Array): void;
    private applyNow;
    /** The local sender's current key index, read through the worker (after earlier events). */
    senderSlot(): Promise<number | undefined>;
    /** The self-check's re-apply is the core's job (it re-emits Activate). */
    get localSlot(): number | undefined;
}
