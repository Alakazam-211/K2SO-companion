# @sew/voice: notices

@sew/voice is Copyright 2026 Alakazam Labs, licensed under either of the MIT License
(LICENSE-MIT) or the Apache License, Version 2.0 (LICENSE-APACHE), at your option
(SPDX: MIT OR Apache-2.0).

The third-party code in this package's `dist/` is the icon paths of the last section (Lucide,
ISC; Feather, MIT). The first section names the noise filter it loads, which is not bundled.

## @sew/noise (0.7.1)

Not bundled here: `src/mic-processor.ts` (the `enhanced` microphone mode) loads the
`@sew/noise` package (a dependency, its own tarball) lazily: nnnoiseless
0.5.2, the pure-Rust port of RNNoise (by Jean-Marc Valin, Mozilla and the Xiph.Org Foundation;
both BSD-3-Clause), built to WebAssembly in the Sew core (`crates/sew-noise-wasm`, commit
2275837b, the 0.8.2 vendoring) and vendored, as built, under `vendor/sew-noise/2275837b/` (`tools.lock` row
`sew-noise`). That package carries its own `NOTICE` (Alakazam Labs, MIT OR Apache-2.0, and nnnoiseless's
BSD-3-Clause text) and `notices/THIRD_PARTY_NOTICES.txt` (every crate compiled into
`sew_noise_wasm_bg.wasm`, with its licence texts); an App's `sew-notices` output carries both
(the `@sew/noise` entry). nnnoiseless's notice, which any redistribution must reproduce:

    nnnoiseless 0.5.2 (COPYING), BSD-3-Clause:
    
    Copyright (c) 2020, Joe Neeman
    Copyright (c) 2017, Mozilla
    Copyright (c) 2007-2017, Jean-Marc Valin
    Copyright (c) 2005-2017, Xiph.Org Foundation
    Copyright (c) 2003-2004, Mark Borgerding
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
    - Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    - Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    
    - Neither the name of the Xiph.Org Foundation nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.
    
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
    OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## Lucide (ISC) and Feather (MIT)

The "plus" path in `src/icons.tsx` comes from Lucide and the "x" (close) path from Feather, which
Lucide's licence also covers. This package also depends on lucide-react 1.48.0 (ISC), which ships
the same text. The other drawings in `src/icons.tsx` are Alakazam Labs' own (K2 Companion's).

    ISC License
    
    Copyright (c) 2026 Lucide Icons and Contributors
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted, provided that the above
    copyright notice and this permission notice appear in all copies.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
    WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
    MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
    ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
    WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
    ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
    OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
    
    ---
    
    The following Lucide icons are derived from the Feather project:
    
    airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
    
    The MIT License (MIT) (for the icons listed above)
    
    Copyright (c) 2013-present Cole Bemis
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
