# Changelog: @sew/voice

## 0.8.2 (2026-11-06)

- Native self-view mirrors by the camera's facing, per frame: the plugin stamps each
  `local:camera` frame's flags with the camera's facing (`FLAG.front` 8, `FLAG.back` 16), and
  the `NativeVideoHandle` mirrors a front camera's frames (a `scaleX(-1)` transform set as that
  frame is shown), so a front/back switch never shows a frame the wrong way round; back or
  unknown facing is not mirrored, remote tracks and `local:screen` never are. The handle gives
  the facing as `onFacing(facing)` (an option, and a method returning the unsubscribe), `facing`,
  and `data-facing` / `data-mirrored` on the element; `mirrorSelfView: 'auto' | 'never' |
  'always'` (on the handle, `PluginVideo` and the camera preview; default `auto`) and
  `setMirrorSelfView()` for hosts that mirror themselves (`never` leaves the element's transform
  alone). The kit's tiles and device check now use it for "Mirror my video" (on: front and
  unknown-facing cameras; off: never) instead of the `sv-mirror` class. `HostTileInfo.mirror` is
  `false` when the handle mirrors the frames itself (a native self-view with `mirrorSelfView`
  `auto` or `always`), so a host that applies it never mirrors twice; it stays the user's
  "Mirror my video" setting with `mirrorSelfView: 'never'` and in the browser. The handle's
  `mirrorSelfView` getter gives its mode.
- Native video: camera, screen share, the device lists and self-view in a Tauri shell on
  tauri-plugin-sew-voice. `PluginVideo` (exported, with `pluginVideo`) is the kit's
  `NativeVideo`, and `createVoiceController` passes it by default in a shell (`native.video:
  false` for none, or your own); the template apps get it that way (a signed-in session there
  now uses `createVoiceController` too). It reads `video_caps` and `video_devices`, follows
  `sew-voice://video`, `local_video`, `video_devices` and `policy` (all four in
  `PLUGIN_EVENTS`), and drives `camera {on, device?}`, `set_video_device` (a live camera
  switch; the front/back switch picks the camera facing the other way), `screen {on, source?}`
  (a listed source, or the OS picker without one), `screen_sources` (with thumbnails) and
  `preview`. `NativeVideo` gains optional members (`start`, `info`, `tracksOf`,
  `setCameraDevice`, `flipCamera`, `cameras`, `screenSources`, `preview`, `reset`), and
  `setScreen(on, source?)` / `handles(identity, local, memberId?)` take one more argument.
- The self-view is the plugin's `local:camera` / `local:screen` sinks; remote tiles are
  `NativeVideoHandle`s (now exported, with `nativeVideoHandle`, `browserVideoEnv`,
  `globalTauriBridge` and `probeDecode`) on the tracks of `sew-voice://video` (a muted or
  unsupported track shows the avatar). Each participant carries `cameraTrack` and `screenTrack`
  where the controller knows them.
- The default bridge has raw channels: `findNativeBridge()` gives `channel()` from
  `window.__TAURI__.core.Channel`, or from `__TAURI_INTERNALS__` alone (`internalsChannel`:
  Tauri 2's ordering of channel messages, serialised as `__CHANNEL__:<id>`).
- `snapshot().videoControls` (native only; `null` without native video, absent in the browser):
  for the camera and the screen, `shown` (this device can send it and the room has video),
  `enabled`, `reason` (why disabled: the session's `camera_allowed` / `screen_allowed`, or a
  refusal that holds for the call: `video_not_allowed`, `video_disabled`), `paused` (its
  sentence while the engine pauses it: the background, a minimised window, heat), plus
  `canSwitch` and the screen's `sources` / `picker`. The call bar hides or disables its camera
  and screen buttons from it, shows a switch-camera button, the paused sentence, and the new
  `<ScreenPicker>` (the listed displays and windows, or the OS picker). An older plugin without
  the video commands, an engine without video and a window without `sew-voice:video` hide the
  buttons; nothing throws.
- The native media policy: the gateway's last (`media_policy_updated`, a move), else the
  plugin's own (`policy` event, the `state` snapshot), else READY's `install.media`, so the
  camera and screen buttons show without a gateway and right after READY (they used to wait for
  a `media_policy_updated`). `camera_allowed` and `screen_allowed` stay the join answer's.
- Refusal sentences for the plugin's video codes: `NATIVE_VIDEO_TEXT`, `VIDEO_PAUSED_TEXT` and
  `videoText(code, source, {apple, retryAfter})` (the slots, the media budget with its wait, the
  OS camera and screen-recording permission naming System Settings on Apple, a camera busy, not
  found or lost, a source gone or closed, the codec, …; a cancelled picker, a stop from the
  OS's own UI and the background say nothing). The engine's `local_video` turning the camera or
  screen off shows its sentence too. A stored camera the engine doesn't have is retried once
  with the engine's own choice and forgotten.
- Host-drawn tiles: `<CallView>` and `<CallTile>` take `renderTile`, `onTileRect` and
  `tileChrome` (`HostTiles`). `renderTile({participant, source, track, handle, key, mirror,
  focus})` returns what goes in the tile's video rect (`undefined`: the kit's own <video>); the
  rect is then transparent with nothing of the kit's over it (the name, mute mark and consent go
  below it, or nowhere with `tileChrome: 'none'`), and `onTileRect(t, rect)` reports its
  `getBoundingClientRect()` on mount, resize, window resize and scroll (`null` when it goes),
  for a native layer (`AVSampleBufferDisplayLayer`) placed at that rect.
- `VoiceControllerApi` gains optional `videoDevices()`, `screenSources()`, `shareScreen(source)`,
  `switchCamera()` and `previewCamera(on, deviceId?)`. `<DeviceSettings />` on a native engine
  lists the engine's cameras (ids that `camera` and `set_video_device` take), never opens the
  webview's camera, and offers "Check camera" (the plugin's preview after the permission, from
  the button only).

- The native camera asks for its permission itself: tauri-plugin-sew-voice no longer prompts,
  and refuses `camera {on}`, `preview {on}` and a join's camera with
  `camera_permission_not_determined` or `camera_permission_denied` until the permission is
  granted. `NativeVoiceController`'s camera button reads `camera_permission`, asks
  `request_camera_permission` only when it was never asked (after the shell's own
  `requestCameraPermission` option, Android's CAMERA request), and turns the camera on only
  when granted. `NativeCameraPreview` does the same for the plugin's `preview`, from `start()`
  only; nothing prompts on a join, a mount or an event. `ensureCameraPermission` is the shared
  step. Both codes have sentences (`NATIVE_NOTICE_TEXT`, `cameraPermissionText(code, apple)`:
  on Apple the denied one names System Settings → Privacy & Security → Camera; the `apple`
  option, default `isApplePlatform()`), shown in the call's notice, also when the plugin's
  `local_video` turns the camera off with either code (`local_video` joins `PLUGIN_EVENTS`).
- Native calls with the same parts. `VoiceControllerApi` is what every part reads (the
  browser's `VoiceController` implements it). `NativeVoiceController` drives a call through the
  native shell's voice plugin (`tauri-plugin-sew-voice` 0.4.1: its commands and events,
  including the security code, each participant's engine identity and label, the quality and
  rings); `createVoiceController(host, opts)` picks it when the page runs in a Tauri shell, else
  the browser's. `findNativeBridge`, `probeNativeVoice`, the plugin's JSON types, and
  `NATIVE_UNFILLED` (the snapshot fields a native call cannot fill yet). `NativeVideo` is the
  hook a native video renderer plugs into for camera, screen share and tiles.
- `toggleMute()` and `toggleDeaf()` on `VoiceControllerApi` (the bar's buttons use them): they
  act on this device's latest choice, not the snapshot the UI last drew, so two quick clicks
  toggle twice, and an undeafen goes back to the mute from before the deafen (Sew stores a
  deafen as muted). The native controller trusts its own choice for `CHOICE_MS` (2 s) over Sew's
  echo. A native snapshot's `screenAudio` is `'unsupported'` while sharing (the native screen
  share sends no sound yet), and `NATIVE_UNFILLED` names it.
- `NATIVE_NOTICE_TEXT` and `nativeText(code)`: the sentences for the native engine's own error
  codes and end reasons.
- `<DeviceSettings />` lists the controller's own audio devices when it has some
  (`controller.audioDevices()`, the native engine's).
- The native renderer for Tauri apps on tauri-plugin-sew-voice (`src/native/`, internal for now:
  the native controller uses it). `sink.ts` reads the plugin's frame messages (a 32-byte
  little-endian header, then the encoded frame) and decodes each sink with one WebCodecs
  `VideoDecoder`: H.264 as Annex B (no `description`), configured again when a keyframe's SPS
  names another profile or level; a discontinuity or a reset message resets it; with more than
  three frames queued, deltas are dropped until a keyframe and one is requested; a decoder error
  rebuilds the decoder and requests a keyframe. Frames go to a `MediaStreamTrackGenerator` where
  the webview has one (WebView2, Android WebView), else to a canvas through `captureStream(0)` and
  `requestFrame()` (WKWebView, WebKitGTK); every `VideoFrame` is closed. `video.ts` probes
  WebCodecs once (`vp8`, `avc1.42E01F`) and gives a `VideoHandle` per track: the first `attach`
  opens the sink, size and visibility follow `ResizeObserver` and `IntersectionObserver`
  (debounced 250 ms, device pixels), the decoder's counters go to the plugin every second, and
  the sink closes 2 s after the last `detach`.
- Screen-share sound: a screen share also sends its sound where the browser can capture it
  (Chromium: a tab's sound, and the system's on Windows and ChromeOS), as its own
  `screen_share_audio` track, end-to-end encrypted, without voice processing (Opus at 64 kbit/s,
  no DTX). Sew grants it with the screen-share lease to people who can speak in the channel.
  `VoiceSnapshot.screenAudio` says `on`, `not_shared`, `unsupported` or `not_allowed`; `CallBar`
  shows a plain sentence when a share goes without sound. `ControllerOptions.screenAudio: false`
  shares the picture only.
- Video codecs: the camera and the screen publish in the first codec of the server's
  `MediaPolicy.codecs` that the browser can send (`pickVideoCodec` in `@sew/voice/media`). With
  Sew's default list (`["vp8", "h264"]`) that is VP8, as before; the screen now follows the
  server's list too (it used livekit's default, also VP8). A browser that can send none of the
  listed codecs sends no video and says so.
- `CallMedia.publishScreen(hint, codecs?, opts?)` and the optional `CallMedia.screenAudio()`, for
  a host's own media seam.

## 0.8.1 (2026-11-06)

- The version follows the kit's 0.8.1. No change in this package.

## 0.8.0 (2026-11-05)

- Leave reason `app_unlinked` (29, Sew 0.8.0): K2 removed this App's participant link to the
  Space, so the joins made through this App ended. A plain leave, no rejoin, with the sentence
  "This space is no longer shown in this App, so you left the call."

## 0.7.4 (2026-11-05)

- The version follows the kit's 0.7.4. No change in this package.

## 0.7.3 (2026-11-04)

- Licence: @sew/voice is now `MIT OR Apache-2.0`, at your option; it was `Apache-2.0`. The package
  ships `LICENSE-MIT` and `LICENSE-APACHE` instead of `LICENSE`, and `package.json`'s
  `license` says `MIT OR Apache-2.0`.
- `NOTICE.md` states the new licence and names the third-party code `dist/` bundles (the
  Lucide and Feather icon paths, ISC and MIT).
