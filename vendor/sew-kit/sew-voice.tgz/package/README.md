# @sew/voice

Part of the **Sew App kit** (MIT OR Apache-2.0): Sew voice channels and calls as React parts. Join and
leave, who is in with speaking rings, the call bar (mute, deafen, camera, screen, leave), the call
view with video tiles, the device check, the E2EE security code, DM call rings and one media
owner per browser.

- `VoiceController`: the host passes an HTTP sender (your BFF's `/sew/api/v1`), the store, gateway
  events and the E2EE worker and WASM URLs (from `@sew/e2ee`, served from your origin).
- `createVoiceController`: the same parts on a native call when the page runs in a Tauri shell
  with Sew's voice plugin (`NativeVoiceController`), else `VoiceController`.
- `VoiceProvider`, `CallBar`, `CallView`, `VoiceChannelMembers`, `DeviceCheck`, `IncomingCall`, …
- `livekit-client` 2.22.3 (a peer) and `@sew/e2ee` load lazily on the first voice action
  (`@sew/voice/media`). Calls are end-to-end encrypted; Firefox can't join calls yet.

## Styles

Import `@sew/voice/theme.css` first, then `@sew/voice/styles.css`, and put `class="sew-kit"` on an
ancestor (e.g. `<body>`). theme.css gives every CSS custom property the package reads a
zero-specificity default (today's look), so your own `:root { --accent: … }` wins; its base
controls apply only inside `.sew-kit`. The token list is in `docs/sew-app-kit.md`.

Peers: `react` and `react-dom` ^19, `livekit-client` 2.22.3. Notices: NOTICE.md.
