# @sew/client

Part of the **Sew App kit** (MIT OR Apache-2.0): the browser client for Sew, the chat core. Use it with
`@sew/bff` on your App's server; the browser talks only to your own origin.

| Import | What |
|---|---|
| `@sew/client` | `SewHttp` (Sew's client API through your BFF at `/sew/api/v1`, cookies only, never a bearer; POSTs carry the CSRF header), ids, `GatewayDriver` (the gateway WebSocket behind a 30 s ticket from `POST /sew/ticket`, resume and reconnect), `catchUp` / `bootFromReady` (the change log after every READY) |
| `@sew/client/proto` | Sew's wire types, generated from sew-proto's schema |
| `@sew/client/store` | `SewStore`: READY, channels, members, messages, unread rules, catch-up application |
| `@sew/client/markdown` | Sew's message markdown parsed to a typed AST (no DOM, no framework) |

No framework and no runtime dependency. ES modules, ES2022; consume it with a bundler.

```ts
import { GatewayDriver, SewHttp } from '@sew/client';
import { SewStore } from '@sew/client/store';
```

`examples/minimal-app` and `docs/sew-app-kit.md` in the kit's repository show the whole wiring.
