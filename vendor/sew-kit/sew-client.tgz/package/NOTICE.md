# @sew/client: notices

@sew/client is Copyright 2026 Alakazam Labs, licensed under either of the MIT License
(LICENSE-MIT) or the Apache License, Version 2.0 (LICENSE-APACHE), at your option
(SPDX: MIT OR Apache-2.0).

## Third-party code in this package

None. Everything in `dist/` is Alakazam Labs' own code: the client (HTTP, ids, the gateway machine
and its WebSocket driver, catch-up), the store, the message markdown parser (the Sew core's
dialect) and the wire types generated from the Sew core's `sew-proto` schema (Alakazam Labs,
MIT OR Apache-2.0). The package has no runtime dependencies.
