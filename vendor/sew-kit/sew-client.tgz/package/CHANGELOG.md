# Changelog: @sew/client

## Unreleased

- New (Sew's principal erase, not yet released in a Sew version): the generated types carry
  `Member.erased` (omitted when false), the `erased:<member id>` external id,
  `Message.deleted_reason` (`DeletedReason`, `"erased"`; omitted otherwise), `VanishReason`
  `erased`, the export kinds `DeleteKind` and `RemoveKind` `erased`, `status.erasures`
  (`StatusErasures`) and the alarm `erase_stuck`, the `principal_erase` flag, the reason
  `erase_mode_downgrade`, the audit actions `member.erase`, `member.erase_complete`,
  `member.erase_preview` and `member.erase_replayed`, and the mgmt erase types
  (`MgmtEraseRequest`, `MgmtEraseResult`, `MgmtEraseAccepted`, `MgmtErasuresQuery`,
  `MgmtErasurePage`, `MgmtEraseCounts`, `MgmtEraseKept`, `EraseMode`, `EraseState`,
  `EraseKeptKind`, `EraseKeptReason`).
- New: `isErased(member)`, `isErasedExternalId(s)`, `deletedReason(msg)` (a tombstone's
  `deleted_reason`), `isErasedTombstone(msg)` and `isForwardRemoved(msg)`: a live forward whose
  snapshot Sew blanked with its author's account (`reference.kind` `forward` and no
  `forwarded`; an empty `forwarded.body`, a files-only original, is not one).
- The store keeps an account erase's placeholders: `content_vanished` with reason `erased`
  turns its `tombstone_ids` (roots with live replies) into tombstones with
  `deleted_reason: "erased"`, in the channel and as a thread's root; other reasons drop them
  from memory as before.

## 0.8.1 (2026-11-06)

- The gateway keepalive no longer floods /sew/session when a login lasts longer than about 24
  days (standalone Sew logins last 30 days).

## 0.8.0 (2026-11-05)

- New (Sew 0.8.0, participant links): the generated types carry `Space.participant_app_ids`,
  `ReadySpace.participant_app_ids` and `PersonNotification.participant_app_ids` (absent when
  none; an App session sees only its own id), `VoiceLeaveReason` `app_unlinked` (29), the audit
  actions `space.app_link` and `space.app_unlink`, and the mgmt types `MgmtSpaceAppLinkRequest`,
  `MgmtSpaceAppsChange`, `MgmtAppSpace`, `MgmtAppSpaces` and `MgmtAppSpacesQuery`.
- New: `appLink(space, myAppId)` answers `'governing'`, `'participant'` or `null`, so a
  participant App can hide the controls only the governing App's own UI offers. Type `AppLink`.
- The store keeps `participant_app_ids` next to `app_id` and `governance` (READY, joins,
  `space_member_added`) and applies it from `space_updated` (absent again after an unlink).

## 0.7.4 (2026-11-05)

- New: session keepalive in `GatewayDriver`. When `refresh` returns `{ expiresAt }` (the
  `expires_at` of `POST /sew/session`), the driver asks `/sew/session` again 8 minutes before the
  login expires, from the first READY until it stops or `close()`: never more than once per
  5 minutes, retries after 30 s, 1 min and then every 2 min, and when no retry fits before the
  expiry it leaves the login to the 4004 `session_expired` path and picks up the new expiry from
  it. After every renewal it sends REAUTH with a fresh ticket. A quiet tab (a voice call with no
  other traffic) no longer lets the login lapse, so its call encryption state stays on the same
  login lineage. `refresh` may still return `true` (keepalive off); `keepalive: false` turns it
  off, `keepalive: { leadMs, minGapMs, retry }` tunes it, `wallNow` is the wall clock it compares
  with. New exports: `SessionKeepalive`, `SESSION_KEEPALIVE`, `SessionStatus`, `RefreshResult`,
  `KeepaliveConfig`.

## 0.7.3 (2026-11-04)

- Licence: @sew/client is now `MIT OR Apache-2.0`, at your option; it was `Apache-2.0`. The package
  ships `LICENSE-MIT` and `LICENSE-APACHE` instead of `LICENSE`, and `package.json`'s
  `license` says `MIT OR Apache-2.0`.
- New: `NOTICE.md`, the package's own attribution of the third-party code it bundles.
